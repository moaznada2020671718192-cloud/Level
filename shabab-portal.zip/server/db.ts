import { and, count, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { createHash } from "node:crypto";
import { committeeAccess, committeeSchedules, committeeTasks, InsertUser, mediaAssignments, mediaItems, notifications, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

const COMMITTEE_SEED = [
  { committeeId: "logistics", name: "لجنة التنظيم", shortName: "التنظيم", password: "4230", accent: "orange" },
  { committeeId: "projects", name: "لجنة المشروعات والمبادرات", shortName: "المشروعات والمبادرات", password: "1520", accent: "teal" },
  { committeeId: "pr", name: "لجنة العلاقات العامة", shortName: "العلاقات العامة", password: "6398", accent: "violet" },
  { committeeId: "hr", name: "لجنة الاتش ار", shortName: "الاتش ار", password: "9635", accent: "rose" },
  { committeeId: "social", name: "لجنة السوشيال ميديا", shortName: "السوشيال ميديا", password: "2398", accent: "blue" },
  { committeeId: "training", name: "لجنة التدريب والتطوير", shortName: "التدريب والتطوير", password: "42368", accent: "indigo" },
  { committeeId: "executive", name: "المكتب التنفيذي والميديا", shortName: "المكتب التنفيذي", password: "138675", accent: "gold" },
] as const;

const hashPassword = (password: string) => createHash("sha256").update(password).digest("hex");

export async function ensureCommitteeSeed() {
  const db = await getDb();
  if (!db) return;
  for (const item of COMMITTEE_SEED) {
    await db.insert(committeeAccess).values({ committeeId: item.committeeId, name: item.name, shortName: item.shortName, passwordHash: hashPassword(item.password), accent: item.accent }).onDuplicateKeyUpdate({ set: { name: item.name, shortName: item.shortName, passwordHash: hashPassword(item.password), accent: item.accent } });
  }
}

export async function listCommittees() {
  await ensureCommitteeSeed();
  const db = await getDb();
  if (!db) return COMMITTEE_SEED.map(({ password, ...committee }) => ({ ...committee, scheduleImageUrl: null, scheduleImageKey: null }));
  return db.select({
    committeeId: committeeAccess.committeeId,
    name: committeeAccess.name,
    shortName: committeeAccess.shortName,
    accent: committeeAccess.accent,
    scheduleImageUrl: committeeAccess.scheduleImageUrl,
    scheduleImageKey: committeeAccess.scheduleImageKey,
  }).from(committeeAccess);
}

export async function updateCommitteeScheduleImage(committeeId: string, imageUrl: string, imageKey: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  await db.update(committeeAccess).set({ scheduleImageUrl: imageUrl, scheduleImageKey: imageKey }).where(eq(committeeAccess.committeeId, committeeId));
}

export async function listCommitteeStats() {
  const db = await getDb();
  if (!db) return COMMITTEE_SEED.filter((item) => item.committeeId !== "executive").map((item) => ({ committeeId: item.committeeId, taskCount: 0 }));
  return db.select({ committeeId: committeeTasks.committeeId, taskCount: count(committeeTasks.id) }).from(committeeTasks).groupBy(committeeTasks.committeeId);
}

export async function listCommitteeSchedules(committeeId: string) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(committeeSchedules);
  return (committeeId === "all" ? query : query.where(eq(committeeSchedules.committeeId, committeeId))).orderBy(committeeSchedules.scheduleDate, committeeSchedules.scheduleTime);
}

export async function insertCommitteeSchedule(schedule: { committeeId: string; title: string; scheduleDate: string; scheduleTime?: string; location?: string; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  const result = await db.insert(committeeSchedules).values({ ...schedule, scheduleTime: schedule.scheduleTime || null, location: schedule.location || null, notes: schedule.notes || null });
  return Number((result as any)[0]?.insertId);
}

export async function updateCommitteeSchedule(id: number, schedule: { committeeId: string; title: string; scheduleDate: string; scheduleTime?: string; location?: string; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  await db.update(committeeSchedules).set({ title: schedule.title, scheduleDate: schedule.scheduleDate, scheduleTime: schedule.scheduleTime || null, location: schedule.location || null, notes: schedule.notes || null }).where(and(eq(committeeSchedules.id, id), eq(committeeSchedules.committeeId, schedule.committeeId)));
}

export async function deleteCommitteeSchedule(id: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  const result = await db.delete(committeeSchedules).where(eq(committeeSchedules.id, id));
  return Number((result as any)[0]?.affectedRows ?? 0) > 0;
}

export async function getCommitteeForLogin(committeeId: string) {
  await ensureCommitteeSeed();
  const db = await getDb();
  if (!db) {
    const fallback = COMMITTEE_SEED.find((item) => item.committeeId === committeeId);
    return fallback ? { ...fallback, passwordHash: hashPassword(fallback.password) } : undefined;
  }
  const result = await db.select().from(committeeAccess).where(eq(committeeAccess.committeeId, committeeId)).limit(1);
  return result[0];
}

export async function recordCommitteeLogin(committeeId: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(committeeAccess).set({ lastLoginAt: new Date() }).where(eq(committeeAccess.committeeId, committeeId));
}

export async function listMediaForCommittee(committeeId: string) {
  const db = await getDb();
  if (!db) return [];
  if (committeeId === "executive") {
    return db.select({
      id: mediaItems.id,
      title: mediaItems.title,
      description: mediaItems.description,
      type: mediaItems.type,
      url: mediaItems.url,
      fileName: mediaItems.fileName,
      mimeType: mediaItems.mimeType,
      size: mediaItems.size,
      createdAt: mediaItems.createdAt,
    }).from(mediaItems).orderBy(desc(mediaItems.createdAt));
  }
  return db.select({
    id: mediaItems.id,
    title: mediaItems.title,
    description: mediaItems.description,
    type: mediaItems.type,
    url: mediaItems.url,
    fileName: mediaItems.fileName,
    mimeType: mediaItems.mimeType,
    size: mediaItems.size,
    createdAt: mediaItems.createdAt,
  }).from(mediaItems)
    .innerJoin(mediaAssignments, eq(mediaItems.id, mediaAssignments.mediaId))
    .where(eq(mediaAssignments.committeeId, committeeId))
    .orderBy(desc(mediaItems.createdAt));
}

export async function insertMediaWithAssignments(media: {
  title: string;
  description?: string;
  type: "video" | "pdf";
  url: string;
  storageKey: string;
  fileName: string;
  mimeType: string;
  size: number;
  committeeIds: string[];
}) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  const insertResult = await db.insert(mediaItems).values({
    title: media.title,
    description: media.description || null,
    type: media.type,
    url: media.url,
    storageKey: media.storageKey,
    fileName: media.fileName,
    mimeType: media.mimeType,
    size: media.size,
  });
  const mediaId = Number((insertResult as any)[0]?.insertId);
  if (!mediaId) throw new Error("تعذر إنشاء سجل الملف");
  await db.insert(mediaAssignments).values(media.committeeIds.map((committeeId) => ({ mediaId, committeeId })));
  return mediaId;
}

export async function deleteMediaItem(mediaId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  await db.delete(mediaAssignments).where(eq(mediaAssignments.mediaId, mediaId));
  const result = await db.delete(mediaItems).where(eq(mediaItems.id, mediaId));
  return Number((result as any)[0]?.affectedRows ?? 0) > 0;
}

export async function listTasksForCommittee(committeeId: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(committeeTasks).where(eq(committeeTasks.committeeId, committeeId)).orderBy(desc(committeeTasks.createdAt));
}

export async function listAllCommitteeTasks() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: committeeTasks.id,
    committeeId: committeeTasks.committeeId,
    committeeName: committeeAccess.name,
    title: committeeTasks.title,
    description: committeeTasks.description,
    status: committeeTasks.status,
    rating: committeeTasks.rating,
    attachmentUrl: committeeTasks.attachmentUrl,
    attachmentName: committeeTasks.attachmentName,
    attachmentMimeType: committeeTasks.attachmentMimeType,
    attachmentSize: committeeTasks.attachmentSize,
    createdAt: committeeTasks.createdAt,
    updatedAt: committeeTasks.updatedAt,
  }).from(committeeTasks).leftJoin(committeeAccess, eq(committeeTasks.committeeId, committeeAccess.committeeId)).orderBy(desc(committeeTasks.createdAt));
}


export async function updateCommitteeTaskStatus(taskId: number, status: "new" | "reviewing" | "approved" | "needs_revision") {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  await db.update(committeeTasks).set({ status }).where(eq(committeeTasks.id, taskId));
  const task = await db.select({ committeeId: committeeTasks.committeeId }).from(committeeTasks).where(eq(committeeTasks.id, taskId)).limit(1);
  const labels = { new: "جديد", reviewing: "قيد المراجعة", approved: "تم الاعتماد", needs_revision: "يحتاج تعديل" } as const;
  if (task[0]) await db.insert(notifications).values({ committeeId: task[0].committeeId, taskId, type: "task_status", message: `تم تحديث حالة التسك إلى ${labels[status]}` });
}

export async function updateCommitteeTaskRating(taskId: number, rating: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  await db.update(committeeTasks).set({ rating }).where(eq(committeeTasks.id, taskId));
}

export async function deleteCommitteeTask(taskId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  await db.delete(notifications).where(eq(notifications.taskId, taskId));
  const result = await db.delete(committeeTasks).where(eq(committeeTasks.id, taskId));
  return Number((result as any)[0]?.affectedRows ?? 0) > 0;
}

export async function createTaskNotification(taskId: number, committeeId: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values({ committeeId, taskId, type: "task_submitted", message: "تم رفع تسك جديد ويحتاج إلى المراجعة" });
}

export async function listNotifications(committeeId?: string) {
  const db = await getDb();
  if (!db) return [];
  if (committeeId) return db.select().from(notifications).where(eq(notifications.committeeId, committeeId)).orderBy(desc(notifications.createdAt)).limit(30);
  return db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(30);
}

export async function insertCommitteeTask(task: {
  committeeId: string;
  title: string;
  description?: string;
  attachmentUrl?: string;
  attachmentKey?: string;
  attachmentName?: string;
  attachmentMimeType?: string;
  attachmentSize?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا");
  const result = await db.insert(committeeTasks).values({ ...task, description: task.description || null });
  return Number((result as any)[0]?.insertId);
}

export { COMMITTEE_SEED, hashPassword };
