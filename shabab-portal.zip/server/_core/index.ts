import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter, readCommitteeToken } from "../routers";
import { storagePreparePutForKey } from "../storage";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function registerStreamingMediaUpload(app: express.Express) {
  app.post("/api/media/upload-stream", async (req, res) => {
    const authorization = typeof req.headers.authorization === "string" ? req.headers.authorization : "";
    const sessionToken = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
    const session = await readCommitteeToken(sessionToken);
    if (!session?.isExecutive || session.committeeId !== "executive") {
      res.status(401).json({ message: "جلسة المكتب التنفيذي غير صالحة." });
      return;
    }
    const storageKey = typeof req.query.key === "string" ? req.query.key : "";
    if (!/^committee-media\/[A-Za-z0-9._-]+$/.test(storageKey)) {
      res.status(400).json({ message: "مفتاح رفع الفيديو غير صالح." });
      return;
    }

    let uploadUrl: string;
    try {
      const prepared = await storagePreparePutForKey(storageKey);
      uploadUrl = prepared.uploadUrl;
      const parsedUrl = new URL(uploadUrl);
      if (parsedUrl.protocol !== "https:") throw new Error("insecure upload url");
    } catch {
      res.status(502).json({ message: "تعذر تجهيز اتصال التخزين لرفع الفيديو." });
      return;
    }

    const contentType = typeof req.headers["content-type"] === "string" ? req.headers["content-type"] : "application/octet-stream";
    const contentLength = typeof req.headers["content-length"] === "string" ? req.headers["content-length"] : undefined;
    try {
      const upstream = await fetch(uploadUrl, {
        method: "PUT",
        headers: {
          "Content-Type": contentType,
          ...(contentLength ? { "Content-Length": contentLength } : {}),
        },
        body: req as unknown as BodyInit,
        // Node's fetch requires this flag when a request stream is used as the body.
        duplex: "half",
      } as RequestInit & { duplex: "half" });
      if (!upstream.ok) {
        const upstreamMessage = await upstream.text().catch(() => "");
        console.error(`[media-upload] storage returned ${upstream.status}: ${upstreamMessage.slice(0, 300)}`);
        res.status(502).json({ message: `التخزين رفض رفع الفيديو (${upstream.status}).` });
        return;
      }
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("[media-upload] streaming upload failed", error);
      if (!res.headersSent) res.status(502).json({ message: "تعذر توصيل الفيديو إلى التخزين. حاول مرة أخرى." });
    }
  });
}

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Register before express.json so large videos remain a streaming request and never enter memory.
  registerStreamingMediaUpload(app);
  // Base64 uploads add overhead, so keep enough headroom for 150MB media files.
  app.use(express.json({ limit: "220mb" }));
  app.use(express.urlencoded({ limit: "220mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
