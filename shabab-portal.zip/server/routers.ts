import { SignJWT, jwtVerify } from "jose";
import { createHash } from "node:crypto";
import { z } from "zod";
import { storageGet, storageObjectExists, storagePreparePut, storagePut } from "./storage";
import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { COMMITTEE_SEED, createTaskNotification, deleteCommitteeSchedule, deleteCommitteeTask, deleteMediaItem, getCommitteeForLogin, insertCommitteeSchedule, insertCommitteeTask, insertMediaWithAssignments, listAllCommitteeTasks, listCommitteeSchedules, listCommitteeStats, listCommittees, listMediaForCommittee, listNotifications, listTasksForCommittee, recordCommitteeLogin, updateCommitteeSchedule, updateCommitteeScheduleImage, updateCommitteeTaskRating, updateCommitteeTaskStatus } from "./db";

const sessionSecret = new TextEncoder().encode(process.env.JWT_SECRET || "shabab-portal-local-secret");
type CommitteeSession = { committeeId: string; isExecutive: boolean };
const failedLogins = new Map<string, { count: number; resetAt: number }>();

async function createCommitteeToken(session: CommitteeSession) {
  return new SignJWT(session).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("8h").sign(sessionSecret);
}

export async function readCommitteeToken(token: string | undefined): Promise<CommitteeSession | null> {
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, sessionSecret);
    if (typeof payload.committeeId !== "string") return null;
    return { committeeId: payload.committeeId, isExecutive: payload.isExecutive === true };
  } catch {
    return null;
  }
}

function hashPassword(password: string) {
  return createHash("sha256").update(password).digest("hex");
}

const tokenInput = z.object({ token: z.string().min(1) });

export function validateMediaUpload(input: { type: "video" | "pdf"; fileName: string; mimeType: string; size: number }) {
  if (input.type === "video") {
    const extension = input.fileName.toLowerCase().split(".").pop();
    const normalizedMimeType = input.mimeType.split(";", 1)[0].trim().toLowerCase();
    const supportedMimeType = ["video/mp4", "video/webm", "video/quicktime", "application/octet-stream"].includes(normalizedMimeType);
    if (extension !== "mp4" && extension !== "webm" && extension !== "mov" && !supportedMimeType) return "ارفع فيديو بصيغة MP4 أو WEBM أو MOV.";
    if (input.mimeType && !supportedMimeType) return "نوع الفيديو غير مدعوم. استخدم ملف MP4 أو WEBM أو MOV.";
    if (input.size > 10 * 1024 * 1024 * 1024) return "الحد الأقصى لحجم الفيديو هو 10 جيجابايت.";
    return null;
  }
  return input.size > 70 * 1024 * 1024 ? "الحد الأقصى لحجم ملف PDF هو 70 ميجابايت." : null;
}

export function validateTaskRating(rating: number) {
  return Number.isInteger(rating) && rating >= 1 && rating <= 10 ? null : "التقييم يجب أن يكون رقمًا صحيحًا من 1 إلى 10.";
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  committee: router({
    list: publicProcedure.query(async () => listCommittees()),
    stats: publicProcedure.query(async () => listCommitteeStats()),
    login: publicProcedure.input(z.object({ committeeId: z.string(), password: z.string().min(1) })).mutation(async ({ input }) => {
      const now = Date.now();
      const attempts = failedLogins.get(input.committeeId);
      if (attempts && attempts.resetAt > now && attempts.count >= 5) throw new Error("تم إيقاف المحاولات مؤقتًا. حاول بعد دقيقة.");
      const committee = await getCommitteeForLogin(input.committeeId);
      if (!committee) {
        throw new Error("رمز الدخول غير صحيح.");
      }
      if (hashPassword(input.password) !== committee.passwordHash) {
        const current = attempts && attempts.resetAt > now ? attempts : { count: 0, resetAt: now + 60_000 };
        failedLogins.set(input.committeeId, { count: current.count + 1, resetAt: current.resetAt });
        throw new Error("رمز الدخول غير صحيح.");
      }
      failedLogins.delete(input.committeeId);
      const isExecutive = input.committeeId === "executive";
      await recordCommitteeLogin(input.committeeId);
      const token = await createCommitteeToken({ committeeId: input.committeeId, isExecutive });
      return {
        token,
        committeeId: input.committeeId,
        committeeName: committee.name,
        isExecutive,
      };
    }),
  }),

  schedule: router({
    list: publicProcedure.input(tokenInput.extend({ committeeId: z.string() })).query(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session || (!session.isExecutive && session.committeeId !== input.committeeId) || (session.isExecutive && input.committeeId !== "all" && input.committeeId !== session.committeeId)) throw new Error("انتهت جلسة الوصول. سجّل الدخول مجددًا.");
      return listCommitteeSchedules(input.committeeId);
    }),
    create: publicProcedure.input(z.object({ token: z.string().min(1), committeeId: z.string().min(1), title: z.string().trim().min(2).max(180), scheduleDate: z.string().min(1), scheduleTime: z.string().max(20).optional(), location: z.string().trim().max(180).optional(), notes: z.string().trim().max(1000).optional() })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("إدارة الجداول متاحة للمكتب التنفيذي فقط.");
      if (!COMMITTEE_SEED.some((committee) => committee.committeeId === input.committeeId && committee.committeeId !== "executive")) throw new Error("اللجنة المحددة غير صالحة.");
      const id = await insertCommitteeSchedule(input);
      return { id };
    }),
    uploadImage: publicProcedure.input(z.object({ token: z.string().min(1), committeeId: z.string().min(1), fileName: z.string().min(1), mimeType: z.string().regex(/^image\//), dataUrl: z.string().min(1) })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("رفع صور الجداول متاح للمكتب التنفيذي فقط.");
      if (!COMMITTEE_SEED.some((committee) => committee.committeeId === input.committeeId && committee.committeeId !== "executive")) throw new Error("اللجنة المحددة غير صالحة.");
      const match = input.dataUrl.match(/^data:image\/[^;]+;base64,(.+)$/);
      if (!match) throw new Error("صيغة الصورة غير صالحة.");
      const buffer = Buffer.from(match[1], "base64");
      if (buffer.byteLength > 15 * 1024 * 1024) throw new Error("الحد الأقصى لصورة الجدول هو 15 ميجابايت.");
      const cleanName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").slice(-120);
      const stored = await storagePut(`committee-schedules/${input.committeeId}-${Date.now()}-${cleanName}`, buffer, input.mimeType);
      await updateCommitteeScheduleImage(input.committeeId, stored.url, stored.key);
      return { success: true, url: stored.url } as const;
    }),
    update: publicProcedure.input(z.object({ token: z.string().min(1), id: z.number().int().positive(), committeeId: z.string().min(1), title: z.string().trim().min(2).max(180), scheduleDate: z.string().min(1), scheduleTime: z.string().max(20).optional(), location: z.string().trim().max(180).optional(), notes: z.string().trim().max(1000).optional() })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("إدارة الجداول متاحة للمكتب التنفيذي فقط.");
      await updateCommitteeSchedule(input.id, input);
      return { success: true } as const;
    }),
    remove: publicProcedure.input(z.object({ token: z.string().min(1), id: z.number().int().positive() })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("إدارة الجداول متاحة للمكتب التنفيذي فقط.");
      const deleted = await deleteCommitteeSchedule(input.id);
      if (!deleted) throw new Error("موعد الجدول غير موجود.");
      return { success: true } as const;
    }),
  }),

  media: router({
    list: publicProcedure.input(tokenInput.extend({ committeeId: z.string() })).query(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session || session.committeeId !== input.committeeId) throw new Error("انتهت جلسة الوصول. سجّل الدخول مجددًا.");
      return listMediaForCommittee(input.committeeId);
    }),
    prepareUpload: publicProcedure.input(z.object({
      token: z.string().min(1),
      title: z.string().trim().min(2).max(180),
      description: z.string().trim().max(1000).optional(),
      type: z.literal("video"),
      committeeIds: z.array(z.string()).min(1),
      fileName: z.string().min(1),
      mimeType: z.string().min(1),
      size: z.number().int().positive(),
    })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("هذه العملية متاحة للمكتب التنفيذي فقط.");
      const allowedCommittees: string[] = COMMITTEE_SEED.map((item) => item.committeeId);
      if (input.committeeIds.some((committeeId) => !allowedCommittees.includes(committeeId))) throw new Error("توجد لجنة غير صالحة في التوزيع.");
      const validationError = validateMediaUpload(input);
      if (validationError) throw new Error(validationError);
      const cleanName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").slice(-120);
      return storagePreparePut(`committee-media/${Date.now()}-${cleanName}`);
    }),
    completeUpload: publicProcedure.input(z.object({
      token: z.string().min(1),
      title: z.string().trim().min(2).max(180),
      description: z.string().trim().max(1000).optional(),
      type: z.literal("video"),
      committeeIds: z.array(z.string()).min(1),
      fileName: z.string().min(1),
      mimeType: z.string().min(1),
      size: z.number().int().positive(),
      storageKey: z.string().min(1),
      url: z.string().startsWith("/manus-storage/"),
    })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("هذه العملية متاحة للمكتب التنفيذي فقط.");
      const allowedCommittees: string[] = COMMITTEE_SEED.map((item) => item.committeeId);
      if (input.committeeIds.some((committeeId) => !allowedCommittees.includes(committeeId))) throw new Error("توجد لجنة غير صالحة في التوزيع.");
      const validationError = validateMediaUpload(input);
      if (validationError) throw new Error(validationError);
      let stored = false;
      for (let attempt = 0; attempt < 5; attempt += 1) {
        stored = await storageObjectExists(input.storageKey);
        if (stored) break;
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
      if (!stored) throw new Error("اكتمل إرسال الفيديو لكن التخزين لم يؤكد وصوله. اضغط نشر مرة أخرى دون إعادة اختيار الملف.");
      const mediaId = await insertMediaWithAssignments({ title: input.title, description: input.description, type: input.type, url: input.url, storageKey: input.storageKey, fileName: input.fileName, mimeType: input.mimeType, size: input.size, committeeIds: input.committeeIds });
      return { mediaId, url: input.url };
    }),
    upload: publicProcedure.input(z.object({
      token: z.string().min(1),
      title: z.string().trim().min(2).max(180),
      description: z.string().trim().max(1000).optional(),
      type: z.enum(["video", "pdf"]),
      committeeIds: z.array(z.string()).min(1, "اختر لجنة واحدة على الأقل"),
      fileName: z.string().min(1),
      mimeType: z.string().min(1),
      dataUrl: z.string().min(1),
    })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("هذه العملية متاحة للمكتب التنفيذي فقط.");
      const allowedCommittees: string[] = COMMITTEE_SEED.map((item) => item.committeeId);
      if (input.committeeIds.some((committeeId) => !allowedCommittees.includes(committeeId))) throw new Error("توجد لجنة غير صالحة في التوزيع.");
      const match = input.dataUrl.match(/^data:[^;]+;base64,(.+)$/);
      if (!match) throw new Error("صيغة الملف غير صالحة.");
      const buffer = Buffer.from(match[1], "base64");
      const mediaValidationError = validateMediaUpload({ type: input.type, fileName: input.fileName, mimeType: input.mimeType, size: buffer.byteLength });
      if (mediaValidationError) throw new Error(mediaValidationError);
      const cleanName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").slice(-120);
      const storageKey = `committee-media/${Date.now()}-${cleanName}`;
      const stored = await storagePut(storageKey, buffer, input.mimeType);
      const mediaId = await insertMediaWithAssignments({
        title: input.title,
        description: input.description,
        type: input.type,
        url: stored.url,
        storageKey: stored.key,
        fileName: input.fileName,
        mimeType: input.mimeType,
        size: buffer.byteLength,
        committeeIds: input.committeeIds,
      });
      return { mediaId, url: stored.url };
    }),
    remove: publicProcedure.input(z.object({ token: z.string().min(1), mediaId: z.number().int().positive() })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("حذف الملفات متاح للمكتب التنفيذي فقط.");
      const deleted = await deleteMediaItem(input.mediaId);
      if (!deleted) throw new Error("الملف غير موجود أو تم حذفه مسبقًا.");
      return { success: true } as const;
    }),
  }),

  tasks: router({
    list: publicProcedure.input(tokenInput).query(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session) throw new Error("انتهت جلسة الوصول. سجّل الدخول مجددًا.");
      return session.isExecutive ? listAllCommitteeTasks() : listTasksForCommittee(session.committeeId);
    }),
    create: publicProcedure.input(z.object({
      token: z.string().min(1),
      title: z.string().trim().min(2).max(180),
      description: z.string().trim().max(1000).optional(),
      fileName: z.string().optional(),
      mimeType: z.string().optional(),
      dataUrl: z.string().optional(),
    })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session || session.isExecutive) throw new Error("رفع التسك متاح لأعضاء اللجان فقط.");
      let attachment: { url?: string; key?: string; size?: number } = {};
      if (input.dataUrl && input.fileName && input.mimeType) {
        const match = input.dataUrl.match(/^data:[^;]+;base64,(.+)$/);
        if (!match) throw new Error("صيغة المرفق غير صالحة.");
        const buffer = Buffer.from(match[1], "base64");
        if (buffer.byteLength > 70 * 1024 * 1024) throw new Error("الحد الأقصى للمرفق هو 70 ميجابايت.");
        const cleanName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-").slice(-120);
        const stored = await storagePut(`committee-tasks/${Date.now()}-${cleanName}`, buffer, input.mimeType);
        attachment = { url: stored.url, key: stored.key, size: buffer.byteLength };
      }
      const taskId = await insertCommitteeTask({ committeeId: session.committeeId, title: input.title, description: input.description, attachmentUrl: attachment.url, attachmentKey: attachment.key, attachmentName: input.fileName, attachmentMimeType: input.mimeType, attachmentSize: attachment.size });
      await createTaskNotification(taskId, session.committeeId);
      return { taskId };
    }),
    updateStatus: publicProcedure.input(z.object({ token: z.string().min(1), taskId: z.number().int(), status: z.enum(["new", "reviewing", "approved", "needs_revision"]) })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive) throw new Error("تحديث الحالات متاح للمكتب التنفيذي فقط.");
      await updateCommitteeTaskStatus(input.taskId, input.status);
      return { success: true } as const;
    }),
    updateRating: publicProcedure.input(z.object({ token: z.string().min(1), taskId: z.number().int().positive(), rating: z.number().int().min(1).max(10) })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("تقييم التسكات متاح للمكتب التنفيذي فقط.");
      const ratingError = validateTaskRating(input.rating);
      if (ratingError) throw new Error(ratingError);
      await updateCommitteeTaskRating(input.taskId, input.rating);
      return { success: true } as const;
    }),
    remove: publicProcedure.input(z.object({ token: z.string().min(1), taskId: z.number().int().positive() })).mutation(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session?.isExecutive || session.committeeId !== "executive") throw new Error("حذف التسكات متاح للمكتب التنفيذي فقط.");
      const deleted = await deleteCommitteeTask(input.taskId);
      if (!deleted) throw new Error("التسك غير موجود أو تم حذفه مسبقًا.");
      return { success: true } as const;
    }),
  }),

  notifications: router({
    list: publicProcedure.input(tokenInput).query(async ({ input }) => {
      const session = await readCommitteeToken(input.token);
      if (!session) throw new Error("انتهت جلسة الوصول. سجّل الدخول مجددًا.");
      return listNotifications(session.isExecutive ? undefined : session.committeeId);
    }),
  }),
});

export type AppRouter = typeof appRouter;
