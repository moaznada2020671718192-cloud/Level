import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { COMMITTEE_SEED, hashPassword } from "./db";
import type { TrpcContext } from "./_core/context";

const ctx: TrpcContext = {
  user: null,
  req: { protocol: "https", headers: {} } as TrpcContext["req"],
  res: {} as TrpcContext["res"],
};

describe("committee access", () => {
  const originalDatabaseUrl = process.env.DATABASE_URL;

  beforeAll(() => {
    // Keep these unit tests deterministic and avoid mutating the project database.
    delete process.env.DATABASE_URL;
  });

  afterAll(() => {
    if (originalDatabaseUrl === undefined) delete process.env.DATABASE_URL;
    else process.env.DATABASE_URL = originalDatabaseUrl;
  });

  it("keeps the seven committee credentials represented as one-way hashes", () => {
    expect(COMMITTEE_SEED).toHaveLength(7);
    expect(COMMITTEE_SEED.map((committee) => hashPassword(committee.password))).toEqual(
      expect.arrayContaining([
        hashPassword("4230"),
        hashPassword("1520"),
        hashPassword("6398"),
        hashPassword("9635"),
        hashPassword("2398"),
        hashPassword("42368"),
        hashPassword("138675"),
      ]),
    );
  });

  it("opens a committee session with the correct password", async () => {
    const caller = appRouter.createCaller(ctx);
    const result = await caller.committee.login({ committeeId: "logistics", password: "4230" });
    expect(result.committeeId).toBe("logistics");
    expect(result.committeeName).toBe("لجنة التنظيم");
    expect(result.isExecutive).toBe(false);
    expect(result.token.split(".")).toHaveLength(3);
  });

  it("marks the executive session as upload-enabled", async () => {
    const caller = appRouter.createCaller(ctx);
    const result = await caller.committee.login({ committeeId: "executive", password: "138675" });
    expect(result.committeeId).toBe("executive");
    expect(result.isExecutive).toBe(true);
  });

  it("opens the training and development committee with its new password", async () => {
    const caller = appRouter.createCaller(ctx);
    const result = await caller.committee.login({ committeeId: "training", password: "42368" });
    expect(result.committeeName).toBe("لجنة التدريب والتطوير");
    expect(result.isExecutive).toBe(false);
  });

  it("rejects an incorrect password", async () => {
    const caller = appRouter.createCaller(ctx);
    await expect(caller.committee.login({ committeeId: "projects", password: "0000" })).rejects.toThrow("رمز الدخول غير صحيح");
  });

  it("allows a committee member to start a task session but blocks the executive token from submitting", async () => {
    const caller = appRouter.createCaller(ctx);
    const committee = await caller.committee.login({ committeeId: "hr", password: "9635" });
    const executive = await caller.committee.login({ committeeId: "executive", password: "138675" });
    await expect(caller.tasks.create({ token: executive.token, title: "تسك المكتب" })).rejects.toThrow("متاح لأعضاء اللجان فقط");
    expect(committee.isExecutive).toBe(false);
  });

  it("exposes safe public committee stats without task details", async () => {
    const caller = appRouter.createCaller(ctx);
    const stats = await caller.committee.stats();
    expect(stats).toEqual(expect.arrayContaining([{ committeeId: "logistics", taskCount: 0 }]));
    expect(stats[0]).not.toHaveProperty("title");
  });

  it("blocks status updates for non-executive sessions", async () => {
    const caller = appRouter.createCaller(ctx);
    const committee = await caller.committee.login({ committeeId: "hr", password: "9635" });
    await expect(caller.tasks.updateStatus({ token: committee.token, taskId: 1, status: "approved" })).rejects.toThrow();
  });

  it("blocks media and task deletion for committee members", async () => {
    const caller = appRouter.createCaller(ctx);
    const committee = await caller.committee.login({ committeeId: "hr", password: "9635" });
    await expect(caller.media.remove({ token: committee.token, mediaId: 1 })).rejects.toThrow();
    await expect(caller.tasks.remove({ token: committee.token, taskId: 1 })).rejects.toThrow();
  });

  it("blocks schedule management for committee members", async () => {
    const caller = appRouter.createCaller(ctx);
    const committee = await caller.committee.login({ committeeId: "training", password: "42368" });
    await expect(caller.schedule.create({ token: committee.token, committeeId: "training", title: "موعد", scheduleDate: "2026-10-01" })).rejects.toThrow();
  });
});
