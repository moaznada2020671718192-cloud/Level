import { describe, expect, it } from "vitest";
import { validateMediaUpload, validateTaskRating } from "./routers";

const megabyte = 1024 * 1024;

describe("media upload validation", () => {
  it("accepts a normal-sized MP4 video", () => {
    expect(validateMediaUpload({ type: "video", fileName: "training.mp4", mimeType: "video/mp4", size: 120 * megabyte })).toBeNull();
  });

  it("accepts a phone video when the filename has no mp4 extension", () => {
    expect(validateMediaUpload({ type: "video", fileName: "mp4.1000114236", mimeType: "video/mp4", size: 477 * megabyte })).toBeNull();
  });

  it("accepts MP4 MIME values that include codec parameters", () => {
    expect(validateMediaUpload({ type: "video", fileName: "phone-recording", mimeType: "video/mp4; codecs=avc1", size: 20 * megabyte })).toBeNull();
  });

  it("rejects unsupported video extensions", () => {
    expect(validateMediaUpload({ type: "video", fileName: "training.avi", mimeType: "video/avi", size: 20 * megabyte })).toContain("MP4");
  });

  it("accepts videos up to 10GB and rejects larger files", () => {
    expect(validateMediaUpload({ type: "video", fileName: "training.mp4", mimeType: "video/mp4", size: 10 * 1024 * megabyte })).toBeNull();
    expect(validateMediaUpload({ type: "video", fileName: "training.mp4", mimeType: "video/mp4", size: 10 * 1024 * megabyte + 1 })).toContain("10");
  });

  it("keeps the smaller PDF limit", () => {
    expect(validateMediaUpload({ type: "pdf", fileName: "guide.pdf", mimeType: "application/pdf", size: 71 * megabyte })).toContain("70");
  });

  it("accepts task ratings from 1 through 10 only", () => {
    expect(validateTaskRating(1)).toBeNull();
    expect(validateTaskRating(10)).toBeNull();
    expect(validateTaskRating(0)).toContain("1 إلى 10");
    expect(validateTaskRating(11)).toContain("1 إلى 10");
    expect(validateTaskRating(5.5)).toContain("1 إلى 10");
  });
});
