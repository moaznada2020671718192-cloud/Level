CREATE TABLE `committee_access` (
	`committeeId` varchar(64) NOT NULL,
	`name` varchar(180) NOT NULL,
	`shortName` varchar(80) NOT NULL,
	`passwordHash` varchar(128) NOT NULL,
	`accent` varchar(32) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `committee_access_committeeId` PRIMARY KEY(`committeeId`)
);
--> statement-breakpoint
CREATE TABLE `media_assignments` (
	`mediaId` int NOT NULL,
	`committeeId` varchar(64) NOT NULL,
	CONSTRAINT `media_assignments_mediaId_committeeId_pk` PRIMARY KEY(`mediaId`,`committeeId`)
);
--> statement-breakpoint
CREATE TABLE `media_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text,
	`type` enum('video','pdf') NOT NULL,
	`url` text NOT NULL,
	`storageKey` varchar(500) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`size` int,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `media_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `media_items_storageKey_unique` UNIQUE(`storageKey`)
);
