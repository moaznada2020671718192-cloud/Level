import { int, mysqlEnum, mysqlTable, primaryKey, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const committeeAccess = mysqlTable("committee_access", {
  committeeId: varchar("committeeId", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 180 }).notNull(),
  shortName: varchar("shortName", { length: 80 }).notNull(),
  passwordHash: varchar("passwordHash", { length: 128 }).notNull(),
  accent: varchar("accent", { length: 32 }).notNull(),
  scheduleImageUrl: text("scheduleImageUrl"),
  scheduleImageKey: varchar("scheduleImageKey", { length: 500 }),
  lastLoginAt: timestamp("lastLoginAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const committeeSchedules = mysqlTable("committee_schedules", {
  id: int("id").autoincrement().primaryKey(),
  committeeId: varchar("committeeId", { length: 64 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  scheduleDate: varchar("scheduleDate", { length: 20 }).notNull(),
  scheduleTime: varchar("scheduleTime", { length: 20 }),
  location: varchar("location", { length: 180 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const mediaItems = mysqlTable("media_items", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["video", "pdf"]).notNull(),
  url: text("url").notNull(),
  storageKey: varchar("storageKey", { length: 500 }).notNull().unique(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  size: int("size"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const mediaAssignments = mysqlTable("media_assignments", {
  mediaId: int("mediaId").notNull(),
  committeeId: varchar("committeeId", { length: 64 }).notNull(),
}, (table) => ({
  pk: primaryKey({ columns: [table.mediaId, table.committeeId] }),
}));

export const committeeTasks = mysqlTable("committee_tasks", {
  id: int("id").autoincrement().primaryKey(),
  committeeId: varchar("committeeId", { length: 64 }).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["new", "reviewing", "approved", "needs_revision"]).default("new").notNull(),
  rating: int("rating"),
  attachmentUrl: text("attachmentUrl"),
  attachmentKey: varchar("attachmentKey", { length: 500 }),
  attachmentName: varchar("attachmentName", { length: 255 }),
  attachmentMimeType: varchar("attachmentMimeType", { length: 120 }),
  attachmentSize: int("attachmentSize"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  committeeId: varchar("committeeId", { length: 64 }),
  taskId: int("taskId"),
  type: mysqlEnum("type", ["task_submitted", "task_status"]).notNull(),
  message: varchar("message", { length: 255 }).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type CommitteeAccess = typeof committeeAccess.$inferSelect;
export type CommitteeSchedule = typeof committeeSchedules.$inferSelect;
export type MediaItem = typeof mediaItems.$inferSelect;
export type MediaAssignment = typeof mediaAssignments.$inferSelect;
export type CommitteeTask = typeof committeeTasks.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
