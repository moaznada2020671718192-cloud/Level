CREATE TABLE `committee_tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`committeeId` varchar(64) NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text,
	`status` enum('submitted','reviewed') NOT NULL DEFAULT 'submitted',
	`attachmentUrl` text,
	`attachmentKey` varchar(500),
	`attachmentName` varchar(255),
	`attachmentMimeType` varchar(120),
	`attachmentSize` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `committee_tasks_id` PRIMARY KEY(`id`)
);
