CREATE TABLE `committee_schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`committeeId` varchar(64) NOT NULL,
	`title` varchar(180) NOT NULL,
	`scheduleDate` varchar(20) NOT NULL,
	`scheduleTime` varchar(20),
	`location` varchar(180),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `committee_schedules_id` PRIMARY KEY(`id`)
);
