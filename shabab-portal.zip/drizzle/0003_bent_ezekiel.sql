CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int AUTO_INCREMENT NOT NULL,
  `committeeId` varchar(64),
  `taskId` int,
  `type` enum('task_submitted','task_status') NOT NULL,
  `message` varchar(255) NOT NULL,
  `readAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `committee_tasks` MODIFY COLUMN `status` enum('submitted','reviewed','new','reviewing','approved','needs_revision') NOT NULL DEFAULT 'new';
--> statement-breakpoint
UPDATE `committee_tasks` SET `status` = 'approved' WHERE `status` = 'reviewed';
--> statement-breakpoint
UPDATE `committee_tasks` SET `status` = 'new' WHERE `status` = 'submitted';
--> statement-breakpoint
ALTER TABLE `committee_tasks` MODIFY COLUMN `status` enum('new','reviewing','approved','needs_revision') NOT NULL DEFAULT 'new';
--> statement-breakpoint
ALTER TABLE `committee_access` ADD COLUMN IF NOT EXISTS `lastLoginAt` timestamp;
--> statement-breakpoint
ALTER TABLE `committee_tasks` ADD COLUMN IF NOT EXISTS `updatedAt` timestamp DEFAULT (now()) NOT NULL ON UPDATE CURRENT_TIMESTAMP;
