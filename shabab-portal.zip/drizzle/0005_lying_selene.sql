ALTER TABLE `committee_access` ADD `scheduleImageUrl` text;--> statement-breakpoint
ALTER TABLE `committee_access` ADD `scheduleImageKey` varchar(500);