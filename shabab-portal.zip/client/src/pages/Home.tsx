import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Building2,
  Check,
  CheckCircle2,
  ChevronLeft,
  ClipboardList,
  CircleCheck,
  Download,
  Eye,
  EyeOff,
  FileText,
  Filter,
  Film,
  FolderOpen,
  KeyRound,
  LayoutGrid,
  LockKeyhole,
  LogOut,
  Bell,
  CalendarDays,
  Menu,
  MapPin,
  Play,
  Plus,
  Paperclip,
  Radio,
  Send,
  Search,
  ShieldCheck,
  Sparkles,
  Clock3,
  Upload,
  Users,
  Volume2,
  VolumeX,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const LOGO_URL = "/manus-storage/level-up-logo_16f8280d.jpg";
const ENTITY_LOGO_URL = "/manus-storage/organization-logo-original_8dfea5d6.jpg";
const LAUNCH_CHARACTER_URL = "/manus-storage/level-up-game-world_6bafe583.jpg";
const PLANE_URL = "/manus-storage/level-up-plane-transparent_c79a807d.png";

type Committee = {
  committeeId: string;
  name: string;
  shortName: string;
  accent: string;
  scheduleImageUrl?: string | null;
  scheduleImageKey?: string | null;
};

type CommitteeStat = { committeeId: string; taskCount: number };

type Session = {
  token: string;
  committeeId: string;
  committeeName: string;
  isExecutive: boolean;
};

type MediaItem = {
  id: number;
  title: string;
  description: string | null;
  type: "video" | "pdf";
  url: string;
  fileName: string;
  mimeType: string;
  size: number | null;
  createdAt: Date | string;
};

type TaskItem = {
  id: number;
  committeeId: string;
  committeeName?: string | null;
  title: string;
  description: string | null;
  status: "new" | "reviewing" | "approved" | "needs_revision";
  rating: number | null;
  attachmentUrl: string | null;
  attachmentName: string | null;
  attachmentMimeType: string | null;
  attachmentSize: number | null;
  createdAt: Date | string;
  updatedAt?: Date | string;
};

type NotificationItem = { id: number; committeeId: string | null; taskId: number | null; type: "task_submitted" | "task_status"; message: string; readAt: Date | string | null; createdAt: Date | string };
type ScheduleItem = { id: number; committeeId: string; title: string; scheduleDate: string; scheduleTime: string | null; location: string | null; notes: string | null; createdAt: Date | string; updatedAt: Date | string };

const committeeMeta: Record<string, { icon: typeof LayoutGrid; color: string; light: string; label: string }> = {
  logistics: { icon: FolderOpen, color: "text-orange-600", light: "bg-orange-50", label: "01" },
  projects: { icon: Sparkles, color: "text-teal-600", light: "bg-teal-50", label: "02" },
  pr: { icon: Radio, color: "text-violet-600", light: "bg-violet-50", label: "03" },
  hr: { icon: Users, color: "text-rose-600", light: "bg-rose-50", label: "04" },
  social: { icon: ArrowUpRight, color: "text-blue-600", light: "bg-blue-50", label: "05" },
  training: { icon: BookOpen, color: "text-indigo-600", light: "bg-indigo-50", label: "06" },
  executive: { icon: ShieldCheck, color: "text-amber-600", light: "bg-amber-50", label: "07" },
};

function formatBytes(bytes?: number | null) {
  if (!bytes) return "حجم غير محدد";
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} كيلوبايت`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} ميجابايت`;
}

function formatDate(date: Date | string) {
  return new Intl.DateTimeFormat("ar-EG", { day: "numeric", month: "short", year: "numeric" }).format(new Date(date));
}

function Header({ onCommittees, onAbout }: { onCommittees: () => void; onAbout: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="shell header-inner">
        <a className="brand" href="#top" aria-label="منصة شباب التنمية">
          <span className="brand-mark"><span>ش</span></span>
          <span className="brand-copy"><strong>Level Up</strong><small>البرنامج التأهيلي الرسمي لأعضاء YDP</small></span>
        </a>
        <nav className={`main-nav ${open ? "is-open" : ""}`} aria-label="التنقل الرئيسي">
          <button onClick={() => { onCommittees(); setOpen(false); }}>اللجان</button>
          <button onClick={() => { onAbout(); setOpen(false); }}>عن المنصة</button>
          <span className="nav-divider" />
          <span className="nav-status"><i /> نظام آمن ومحدّث</span>
        </nav>
        <div className="header-logos">
          <div className="ministry-logo" title="وزارة الشباب والرياضة"><img src="/manus-storage/ministry-logo_a76eb39a.png" alt="شعار وزارة الشباب والرياضة" /></div>
          <div className="logo-separator" />
          <img src={ENTITY_LOGO_URL} alt="شعار كيان شباب التنمية" className="org-logo entity-logo" />
          <div className="logo-separator" />
          <img src={LOGO_URL} alt="شعار LEVEL UP" className="org-logo level-up-logo" />
        </div>
        <button className="mobile-menu" onClick={() => setOpen(!open)} aria-label="فتح القائمة">{open ? <X size={20} /> : <Menu size={20} />}</button>
      </div>
    </header>
  );
}

function LaunchIntro({ onComplete }: { onComplete: () => void }) {
  const [stage, setStage] = useState<1 | 2>(1);
  const [soundOn, setSoundOn] = useState(true);

  const playLaunchTone = () => {
    if (!soundOn) return;
    const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const audio = new AudioContextClass();
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(220, audio.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(760, audio.currentTime + 0.7);
    gain.gain.setValueAtTime(0.045, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.7);
    oscillator.connect(gain).connect(audio.destination);
    oscillator.start();
    oscillator.stop(audio.currentTime + 0.7);
  };

  useEffect(() => {
    if (stage !== 2) return;
    const exitTimer = window.setTimeout(onComplete, 3000);
    return () => {
      window.clearTimeout(exitTimer);
    };
  }, [stage, onComplete]);

  return <div className={`launch-intro launch-stage-${stage}`} role="status" aria-label="جارٍ فتح منصة شباب التنمية"><div className="launch-progress-wrap"><div className="launch-progress"><span style={{ width: stage === 1 ? "28%" : "78%" }} /></div><small>{stage === 1 ? "الخطوة الأولى · ابدأ الرحلة" : "الخطوة الثانية · فتح المنصة"}</small></div><button className="launch-audio-toggle" onClick={() => setSoundOn((current) => !current)} aria-label={soundOn ? "إيقاف صوت المقدمة" : "تشغيل صوت المقدمة"}>{soundOn ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>
    {stage === 1 ? <button className="launch-character-scene" onClick={() => { playLaunchTone(); setStage(2); }} aria-label="اضغط على عالم اللعبة لفتح المنصة"><img src={LAUNCH_CHARACTER_URL} alt="عالم Level Up التفاعلي" /><div className="launch-character-shade" /><div className="launch-copy"><span className="launch-kicker">LEVEL UP • YDP</span><strong>ابدأ المغامرة</strong><small>اضغط لبدء رحلة اللجان</small></div><span className="launch-character-hint"><Sparkles size={15} /> اضغط للبدء</span></button> : <div className="launch-plane-scene"><div className="plane-skyline" /><div className="plane-glow" /><div className="plane-route route-one" /><div className="plane-route route-two" /><img className="launch-plane" src={PLANE_URL} alt="طائرة Level Up" /><div className="plane-logo"><img src={LOGO_URL} alt="شعار شباب التنمية" /><strong>LEVEL UP</strong><span>البرنامج التأهيلي الرسمي لأعضاء YDP</span></div><div className="launch-plane-copy"><span>نبدأ الرحلة معًا</span><strong>مساحة اللجان الرقمية</strong></div></div>}
    <div className="launch-stage-caption">{stage === 1 ? "اضغط على عالم اللعبة لبدء الرحلة" : "الطائرة في طريقها إلى مساحة اللجان"}</div><button className="launch-skip" onClick={onComplete}>تخطي المقدمة <ArrowLeft size={14} /></button>
  </div>;
}

function CommitteeCard({ committee, onSelect, stat }: { committee: Committee; onSelect: (committee: Committee) => void; stat?: CommitteeStat }) {
  const meta = committeeMeta[committee.committeeId] ?? committeeMeta.logistics;
  const Icon = meta.icon;
  return (
    <button className={`committee-card committee-${committee.committeeId}`} onClick={() => onSelect(committee)}>
      <div className="committee-card-top">
        <span className={`committee-icon ${meta.light} ${meta.color}`}><Icon size={22} strokeWidth={2.1} /></span>
        <span className="committee-number">{meta.label}</span>
      </div>
      <div className="committee-card-body">
        <span className="eyebrow">لجنة متخصصة {stat?.taskCount ? <b className="committee-update-badge">{stat.taskCount} تسك</b> : <b className="committee-ready-badge">مساحة جاهزة</b>}</span>
        <h3>{committee.name}</h3>
      </div>
      <div className="committee-card-footer"><span>دخول مساحة اللجنة</span><ChevronLeft size={16} /></div>
    </button>
  );
}

function LoginPanel({ committee, onClose, onLogin, onClearError, error, loading = false }: { committee: Committee; onClose: () => void; onLogin: (password: string) => void; onClearError: () => void; error?: string; loading?: boolean }) {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const meta = committeeMeta[committee.committeeId] ?? committeeMeta.logistics;
  const Icon = meta.icon;
  return (
    <div className="login-backdrop" role="dialog" aria-modal="true" aria-labelledby="login-title">
      <div className="login-panel">
        <button className="close-button" onClick={onClose} aria-label="إغلاق"><X size={18} /></button>
        <div className={`login-icon ${meta.light} ${meta.color}`}><Icon size={25} /></div>
        <span className="eyebrow">مساحة محمية</span>
        <h2 id="login-title">دخول {committee.shortName}</h2>
        <p>أدخل رمز الدخول الخاص باللجنة للوصول إلى الملفات والفيديوهات المخصصة.</p>
        <label className="field-label" htmlFor="committee-password">رمز الدخول</label>
        <div className="password-field">
          <KeyRound size={17} />
          <input id="committee-password" autoFocus dir="ltr" inputMode="numeric" type={showPassword ? "text" : "password"} value={password} onChange={(event) => { setPassword(event.target.value); onClearError(); }} onKeyDown={(event) => event.key === "Enter" && !loading && onLogin(password)} placeholder="••••••" aria-invalid={Boolean(error)} aria-describedby={error ? "login-error" : undefined} />
          <button className="password-visibility" type="button" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"} title={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button>
        </div>
        {error && <div className="login-error" id="login-error" role="alert"><span>!</span><div><strong>رمز الدخول غير صحيح</strong><small>{error}</small></div></div>}
        <button className={`primary-button full-button login-submit-button ${loading ? "is-loading" : ""}`} onClick={() => onLogin(password)} disabled={!password || loading} aria-busy={loading}>{loading ? <><span className="button-spinner" aria-hidden="true" /> جارٍ التحقق...</> : <><LockKeyhole size={17} /> فتح مساحة اللجنة <ArrowLeft size={17} /></>}</button>
        <div className="secure-note"><ShieldCheck size={15} /> الوصول للقراءة فقط ومخصص لأعضاء اللجنة</div>
      </div>
    </div>
  );
}

function EmptyState({ type }: { type: "video" | "pdf" }) {
  const isVideo = type === "video";
  return <div className="empty-state"><span className="empty-icon">{isVideo ? <Film size={24} /> : <FileText size={24} />}</span><h3>لا توجد {isVideo ? "فيديوهات" : "ملفات PDF"} بعد</h3><p>ستظهر الملفات المخصصة لهذه اللجنة هنا فور نشرها من المكتب التنفيذي.</p></div>;
}

function MediaCard({ item, canDelete, onDelete, deleting }: { item: MediaItem; canDelete?: boolean; onDelete?: (item: MediaItem) => void; deleting?: boolean }) {
  const isVideo = item.type === "video";
  return <article className="media-card">
    {isVideo ? <div className="video-frame"><video controls preload="metadata" src={item.url} aria-label={item.title} /><span className="media-type-pill"><Film size={13} /> فيديو</span></div> : <div className="pdf-frame"><FileText size={36} /><span>PDF</span><iframe src={`${item.url}#toolbar=0&navpanes=0`} title={item.title} /></div>}
    <div className="media-card-content">
      <div className="media-card-heading"><span className={`media-icon ${isVideo ? "video-icon" : "pdf-icon"}`}>{isVideo ? <Play size={15} fill="currentColor" /> : <FileText size={15} />}</span><h3>{item.title}</h3></div>
      {item.description && <p>{item.description}</p>}
      <div className="media-card-meta"><span>{formatDate(item.createdAt)}</span><span>{formatBytes(item.size)}</span></div>
      <div className="media-card-actions"><a className="download-link" href={item.url} download={item.fileName}><Download size={15} /> تحميل {isVideo ? "الفيديو" : "الملف"}</a>{canDelete && <button className="delete-button" type="button" disabled={deleting} onClick={() => onDelete?.(item)}><Trash2 size={14} /> {deleting ? "جارٍ الحذف..." : "حذف"}</button>}</div>
    </div>
  </article>;
}

function SchedulePanel({ session, committees, schedules, onChanged }: { session: Session; committees: Committee[]; schedules: ScheduleItem[]; onChanged: () => void }) {
  const [committeeId, setCommitteeId] = useState(session.isExecutive ? "logistics" : session.committeeId);
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [boardFile, setBoardFile] = useState<File | null>(null);
  const create = trpc.schedule.create.useMutation({ onSuccess: () => { toast.success("تمت إضافة الموعد إلى جدول اللجنة"); setTitle(""); setDate(""); setTime(""); setLocation(""); setNotes(""); onChanged(); }, onError: (error) => toast.error(error.message) });
  const remove = trpc.schedule.remove.useMutation({ onSuccess: () => { toast.success("تم حذف الموعد من الجدول"); onChanged(); }, onError: (error) => toast.error(error.message) });
  const uploadBoard = trpc.schedule.uploadImage.useMutation({ onSuccess: () => { toast.success("تم رفع صورة الجدول للجنة المحددة"); setBoardFile(null); onChanged(); }, onError: (error) => toast.error(error.message) });
  const labels = Object.fromEntries(committees.map((committee) => [committee.committeeId, committee.name]));
  const selectedCommittee = committees.find((committee) => committee.committeeId === (session.isExecutive ? committeeId : session.committeeId));
  const visibleSchedules = schedules.filter((item) => session.isExecutive || item.committeeId === session.committeeId);
  const submit = (event: React.FormEvent) => { event.preventDefault(); if (!date) return toast.error("اختر تاريخ الموعد"); create.mutate({ token: session.token, committeeId: session.isExecutive ? committeeId : session.committeeId, title, scheduleDate: date, scheduleTime: time, location, notes }); };
  const uploadBoardImage = async (event: React.FormEvent) => { event.preventDefault(); if (!boardFile) return toast.error("اختر صورة جدول أولًا"); const dataUrl = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(boardFile); }); uploadBoard.mutate({ token: session.token, committeeId: session.isExecutive ? committeeId : session.committeeId, fileName: boardFile.name, mimeType: boardFile.type, dataUrl }); };
  return <section className="schedule-panel">
    <div className="schedule-heading"><span className="schedule-icon"><CalendarDays size={20} /></span><div><span className="eyebrow">{session.isExecutive ? "إدارة الجداول" : "جدول اللجنة"}</span><h2>{session.isExecutive ? "جداول اللجان" : "الجدول الزمني للجنة"}</h2></div><span className="schedule-live"><i /> محدث</span></div>
    {selectedCommittee?.scheduleImageUrl && <div className="schedule-board-image"><div className="schedule-board-image-heading"><strong>صورة جدول {selectedCommittee.name}</strong><span>الجدول الرسمي للجنة</span></div><img src={selectedCommittee.scheduleImageUrl} alt={`جدول ${selectedCommittee.name}`} /></div>}
    {session.isExecutive && <><form className="schedule-image-form" onSubmit={uploadBoardImage}><select className="text-input" value={committeeId} onChange={(event) => setCommitteeId(event.target.value)}>{committees.filter((committee) => committee.committeeId !== "executive").map((committee) => <option key={committee.committeeId} value={committee.committeeId}>{committee.name}</option>)}</select><label className={`schedule-image-picker ${boardFile ? "has-file" : ""}`}><input type="file" accept="image/*" onChange={(event) => setBoardFile(event.target.files?.[0] ?? null)} /><Upload size={16} /><span>{boardFile ? boardFile.name : "اختر صورة جدول اللجنة"}</span></label><button className="primary-button schedule-add-button" type="submit" disabled={uploadBoard.isPending || !boardFile}><Upload size={16} /> {uploadBoard.isPending ? "جارٍ رفع الصورة..." : "رفع صورة الجدول"}</button></form><p className="schedule-image-help">اختار اللجنة ثم ارفع صورة الجدول؛ ستظهر تلقائيًا في أعلى صفحة اللجنة المختارة. رفع صورة جديدة يستبدل السابقة.</p></>}
    {session.isExecutive && <form className="schedule-form" onSubmit={submit}><select className="text-input" value={committeeId} onChange={(event) => setCommitteeId(event.target.value)}>{committees.filter((committee) => committee.committeeId !== "executive").map((committee) => <option key={committee.committeeId} value={committee.committeeId}>{committee.name}</option>)}</select><input className="text-input" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="عنوان الموعد أو الاجتماع" required /><input className="text-input" type="date" value={date} onChange={(event) => setDate(event.target.value)} required /><input className="text-input" type="time" value={time} onChange={(event) => setTime(event.target.value)} /><input className="text-input" value={location} onChange={(event) => setLocation(event.target.value)} placeholder="المكان (اختياري)" /><input className="text-input" value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="ملاحظات (اختياري)" /><button className="primary-button schedule-add-button" type="submit" disabled={create.isPending}><Plus size={16} /> {create.isPending ? "جارٍ الإضافة..." : "إضافة للجدول"}</button></form>}
    {visibleSchedules.length === 0 ? <div className="schedule-empty"><CalendarDays size={22} /><span>لا توجد مواعيد مضافة لهذه اللجنة حتى الآن.</span></div> : <div className="schedule-list">{visibleSchedules.map((item) => <article className="schedule-item" key={item.id}><div className="schedule-date"><strong>{new Intl.DateTimeFormat("ar-EG", { day: "2-digit", month: "short" }).format(new Date(`${item.scheduleDate}T00:00:00`))}</strong><small>{item.scheduleDate}</small></div><div className="schedule-item-main"><h3>{item.title}</h3><div className="schedule-meta">{item.scheduleTime && <span><Clock3 size={13} /> {item.scheduleTime}</span>}{item.location && <span><MapPin size={13} /> {item.location}</span>}</div>{item.notes && <p>{item.notes}</p>}</div>{session.isExecutive && <button className="schedule-delete" type="button" onClick={() => window.confirm(`حذف موعد «${item.title}»؟`) && remove.mutate({ token: session.token, id: item.id })}><X size={15} /></button>}{session.isExecutive && <small className="schedule-committee-label">{labels[item.committeeId] || item.committeeId}</small>}</article>)}</div>}
  </section>;
}

function UploadPanel({ session, committees, onUploaded }: { session: Session; committees: Committee[]; onUploaded: () => void }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<"video" | "pdf">("video");
  const [selected, setSelected] = useState<string[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const upload = trpc.media.upload.useMutation({ onSuccess: () => { toast.success("تم نشر الملف وتوزيعه على اللجان المحددة"); setTitle(""); setDescription(""); setSelected([]); setFile(null); onUploaded(); }, onError: (error) => toast.error(error.message) });
  const prepareUpload = trpc.media.prepareUpload.useMutation();
  const completeUpload = trpc.media.completeUpload.useMutation();
  const toggleCommittee = (id: string) => setSelected((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!file) return toast.error("اختر ملفًا قبل النشر");
    if (selected.length === 0) return toast.error("اختر لجنة واحدة على الأقل لتوزيع الملف");
    if (type === "video") {
      const extension = file.name.toLowerCase().split(".").pop();
      const normalizedMimeType = file.type.split(";", 1)[0].trim().toLowerCase();
      const supportedMimeType = ["video/mp4", "video/webm", "video/quicktime", "application/octet-stream"].includes(normalizedMimeType);
      if ((!extension || !["mp4", "webm", "mov"].includes(extension)) && !supportedMimeType) return toast.error("ارفع فيديو بصيغة MP4 أو WEBM أو MOV");
      if (file.size > 10 * 1024 * 1024 * 1024) return toast.error("الحد الأقصى لحجم الفيديو هو 10 جيجابايت");
      try {
        setUploadProgress(0);
        let prepared: Awaited<ReturnType<typeof prepareUpload.mutateAsync>> | null = null;
        let lastError: unknown = null;
        for (let attempt = 1; attempt <= 3; attempt += 1) {
          try {
            if (!prepared) prepared = await prepareUpload.mutateAsync({ token: session.token, title, description, type: "video", committeeIds: selected, fileName: file.name, mimeType: file.type || "video/mp4", size: file.size });
            await new Promise<void>((resolve, reject) => {
              const request = new XMLHttpRequest();
              let settled = false;
              const resolveOnce = () => { if (!settled) { settled = true; resolve(); } };
              const rejectOnce = (error: Error) => { if (!settled) { settled = true; reject(error); } };
              request.open("POST", `/api/media/upload-stream?key=${encodeURIComponent(prepared!.key)}`);
              request.setRequestHeader("Authorization", `Bearer ${session.token}`);
              request.setRequestHeader("Content-Type", file.type || "video/mp4");
              request.timeout = 0;
              request.upload.onprogress = (event) => { if (event.lengthComputable) setUploadProgress(Math.round((event.loaded / event.total) * 100)); };
              request.onreadystatechange = () => { if (request.readyState >= 2 && request.status >= 200 && request.status < 300) resolveOnce(); };
              request.onload = () => request.status >= 200 && request.status < 300 ? resolveOnce() : rejectOnce(new Error(`تعذر رفع الفيديو إلى التخزين (${request.status || "اتصال"})`));
              request.onerror = () => rejectOnce(new Error("انقطع الاتصال أثناء رفع الفيديو"));
              request.ontimeout = () => rejectOnce(new Error("انتهت مهلة رفع الفيديو"));
              request.send(file);
            });
            setUploadProgress(100);
            break;
          } catch (error) {
            lastError = error;
            if (attempt < 3) {
              toast.info(`انقطع الاتصال، إعادة المحاولة ${attempt + 1} من 3...`);
              await new Promise((resolve) => window.setTimeout(resolve, 1500));
            }
          }
        }
        if (!prepared) throw lastError instanceof Error ? lastError : new Error("تعذر رفع الفيديو بعد عدة محاولات");
        await completeUpload.mutateAsync({ token: session.token, title, description, type: "video", committeeIds: selected, fileName: file.name, mimeType: file.type || "video/mp4", size: file.size, storageKey: prepared.key, url: prepared.url });
        toast.success("تم رفع الفيديو ونشره على اللجان المحددة");
        setTitle(""); setDescription(""); setSelected([]); setFile(null); setUploadProgress(0); onUploaded();
      } catch (error) { setUploadProgress(0); toast.error(error instanceof Error ? error.message : "تعذر رفع الفيديو"); }
      return;
    } else if (file.size > 70 * 1024 * 1024) return toast.error("الحد الأقصى لحجم ملف PDF هو 70 ميجابايت");
    const dataUrl = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(file); });
    upload.mutate({ token: session.token, title, description, type, committeeIds: selected, fileName: file.name, mimeType: file.type || (type === "pdf" ? "application/pdf" : "video/mp4"), dataUrl });
  };
  return <section className="upload-panel">
    <div className="upload-heading"><span className="upload-heading-icon"><Upload size={19} /></span><div><span className="eyebrow">إدارة المحتوى</span><h2>نشر ملف جديد</h2></div></div>
    <p className="upload-intro">ارفع محتوى ووزّعه مباشرة على لجنة واحدة أو أكثر.</p>
    <form onSubmit={submit}>
      <label className="field-label" htmlFor="upload-title">عنوان الملف</label><input className="text-input" id="upload-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="مثال: خطة فعاليات الربع الثالث" required />
      <label className="field-label" htmlFor="upload-description">وصف مختصر <span>اختياري</span></label><textarea className="text-input text-area" id="upload-description" value={description} onChange={(event) => setDescription(event.target.value)} placeholder="أضف تفاصيل تساعد أعضاء اللجنة..." rows={3} />
      <label className="field-label">نوع المحتوى</label><div className="type-switch"><button type="button" className={type === "video" ? "active" : ""} onClick={() => setType("video")}><Film size={16} /> فيديو</button><button type="button" className={type === "pdf" ? "active" : ""} onClick={() => setType("pdf")}><FileText size={16} /> PDF</button></div>
      <label className="field-label">الملف</label><label className={`file-dropzone ${file ? "has-file" : ""}`}><input type="file" accept={type === "video" ? ".mp4,.webm,.mov,video/mp4,video/webm,video/quicktime" : "application/pdf,.pdf"} onChange={(event) => setFile(event.target.files?.[0] ?? null)} /><span className="file-drop-icon">{file ? <CircleCheck size={22} /> : <Plus size={22} />}</span><strong>{file ? file.name : "اضغط لاختيار الملف"}</strong><small>{file ? formatBytes(file.size) : type === "video" ? "MP4, WEBM أو MOV حتى 10 جيجابايت" : "PDF حتى 70 ميجابايت"}</small></label>
      {type === "video" && (prepareUpload.isPending || completeUpload.isPending || uploadProgress > 0) && <div className="upload-progress" role="status"><div className="upload-progress-heading"><span>{completeUpload.isPending ? "جارٍ حفظ الفيديو ونشره..." : "جارٍ رفع الفيديو مباشرة..."}</span><strong>{uploadProgress}%</strong></div><div className="upload-progress-track"><i style={{ width: `${uploadProgress}%` }} /></div></div>}
      <label className="field-label">توزيع الملف <span>مطلوب</span></label><div className="committee-checks">{committees.map((committee) => <label className={`committee-check ${selected.includes(committee.committeeId) ? "checked" : ""}`} key={committee.committeeId}><input type="checkbox" checked={selected.includes(committee.committeeId)} onChange={() => toggleCommittee(committee.committeeId)} /><span className="check-box">{selected.includes(committee.committeeId) && <Check size={13} />}</span><span>{committee.shortName}</span></label>)}</div>
      <button className="primary-button full-button publish-button" type="submit" disabled={upload.isPending || prepareUpload.isPending || completeUpload.isPending || !title || !file}><Upload size={17} /> {upload.isPending || prepareUpload.isPending || completeUpload.isPending ? "جارٍ الرفع والنشر..." : "نشر وتوزيع الملف"}</button>
    </form>
  </section>;
}

function TaskSubmitPanel({ session, onSubmitted }: { session: Session; onSubmitted: () => void }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const submitTask = trpc.tasks.create.useMutation({ onSuccess: () => { toast.success("تم رفع التسك وإرساله للمكتب التنفيذي"); setTitle(""); setDescription(""); setFile(null); onSubmitted(); }, onError: (error) => toast.error(error.message) });
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    let dataUrl: string | undefined;
    if (file) dataUrl = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(file); });
    submitTask.mutate({ token: session.token, title, description, fileName: file?.name, mimeType: file?.type, dataUrl });
  };
  return <section className="task-submit-panel">
    <div className="task-panel-heading"><span className="task-heading-icon"><Send size={18} /></span><div><span className="eyebrow">مساحة اللجنة</span><h2>تسليم التسك</h2></div><span className="task-owner">خاص بـ {session.committeeName}</span></div>
    <p className="task-intro">اكتب اسم التسك وارفع الملف إن وجد، وسيظهر فورًا في لوحة المكتب التنفيذي والميديا.</p>
    <form className="task-form" onSubmit={submit}>
      <div><label className="field-label" htmlFor="task-title">اسم التسك</label><input className="text-input" id="task-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="مثال: خطة محتوى شهر أكتوبر" required /></div>
      <div><label className="field-label" htmlFor="task-description">ملاحظات التسك <span>اختياري</span></label><textarea className="text-input text-area" id="task-description" value={description} onChange={(event) => setDescription(event.target.value)} placeholder="اكتب ملخصًا أو ملاحظات للمكتب التنفيذي..." rows={2} /></div>
      <label className={`task-file ${file ? "has-file" : ""}`}><input type="file" onChange={(event) => setFile(event.target.files?.[0] ?? null)} /><Paperclip size={17} /><span>{file ? file.name : "إرفاق ملف التسك (اختياري)"}</span>{file && <small>{formatBytes(file.size)}</small>}</label>
      <button className="primary-button task-submit-button" type="submit" disabled={submitTask.isPending || !title}><Send size={16} /> {submitTask.isPending ? "جارٍ الإرسال..." : "إرسال التسك"}</button>
    </form>
  </section>;
}

function TaskBoard({ tasks, isExecutive, onStatusChange, updatingTaskId, onRatingChange, updatingRatingId, onDeleteTask, deletingTaskId }: { tasks: TaskItem[]; isExecutive: boolean; onStatusChange?: (taskId: number, status: TaskItem["status"]) => void; updatingTaskId?: number | null; onRatingChange?: (taskId: number, rating: number) => void; updatingRatingId?: number | null; onDeleteTask?: (task: TaskItem) => void; deletingTaskId?: number | null }) {
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [committeeFilter, setCommitteeFilter] = useState("all");
  const committeeOrder = ["hr", "logistics", "pr", "social", "projects", "training"];
  const committeeLabels: Record<string, string> = { hr: "لجنة الاتش ار", logistics: "لجنة التنظيم", pr: "لجنة العلاقات العامة", social: "لجنة السوشيال ميديا", projects: "لجنة المشروعات والمبادرات", training: "لجنة التدريب والتطوير" };
  const statusMeta: Record<string, { label: string; className: string }> = { new: { label: "جديد", className: "status-new" }, reviewing: { label: "قيد المراجعة", className: "status-reviewing" }, approved: { label: "تم الاعتماد", className: "status-approved" }, needs_revision: { label: "يحتاج تعديل", className: "status-needs-revision" } };
  const filteredTasks = tasks.filter((task) => (!query || `${task.title} ${task.description || ""}`.toLowerCase().includes(query.toLowerCase())) && (statusFilter === "all" || task.status === statusFilter) && (committeeFilter === "all" || task.committeeId === committeeFilter));
  const rows = isExecutive ? committeeOrder.map((committeeId) => ({ committeeId, committeeName: committeeLabels[committeeId], tasks: filteredTasks.filter((task) => task.committeeId === committeeId) })) : [{ committeeId: tasks[0]?.committeeId || "current", committeeName: tasks[0]?.committeeName || "لجنة اللجنة", tasks: filteredTasks }];
  const statusBadge = (task: TaskItem) => <span className={`task-status ${statusMeta[task.status]?.className || "status-new"}`}><CheckCircle2 size={14} /> {statusMeta[task.status]?.label || "جديد"}</span>;
  return <section className="task-board">
    <div className="library-heading task-board-heading"><div><span className="eyebrow"><ClipboardList size={14} /> {isExecutive ? "المتابعة المركزية" : "تسكات اللجنة"}</span><h2>{isExecutive ? "تسكات اللجان المرفوعة" : "التسكات التي تم تسليمها"}</h2></div><span className="task-count"><ClipboardList size={14} /> {filteredTasks.length} من {tasks.length} تسك</span></div>
    <div className="task-filters"><label className="task-search"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث باسم التسك..." /></label><label className="task-select"><Filter size={14} /><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}><option value="all">كل الحالات</option><option value="new">جديد</option><option value="reviewing">قيد المراجعة</option><option value="approved">تم الاعتماد</option><option value="needs_revision">يحتاج تعديل</option></select></label>{isExecutive && <label className="task-select"><select value={committeeFilter} onChange={(event) => setCommitteeFilter(event.target.value)}><option value="all">كل اللجان</option>{committeeOrder.map((id) => <option key={id} value={id}>{committeeLabels[id]}</option>)}</select></label>}</div>
    {tasks.length === 0 ? <div className="task-empty"><ClipboardList size={27} /><h3>لا توجد تسكات مرفوعة بعد</h3><p>{isExecutive ? "ستظهر هنا تسكات اللجان فور إرسالها." : "ابدأ بتسليم أول تسك للجنة."}</p></div> : filteredTasks.length === 0 ? <div className="task-empty"><Search size={27} /><h3>لا توجد نتائج مطابقة</h3><p>جرّب تغيير البحث أو الفلاتر.</p></div> : isExecutive ? <div className="task-table-wrap"><table className="task-table"><thead><tr><th>اللجنة</th><th>اسم التسك</th><th>الحالة</th><th>التقييم</th><th>تاريخ الرفع</th><th>المرفق</th><th>إجراء</th></tr></thead><tbody>{rows.map((row) => row.tasks.length === 0 ? <tr key={row.committeeId} className="task-row-empty"><td><strong>{row.committeeName}</strong></td><td colSpan={6}>لا توجد نتائج لهذه اللجنة</td></tr> : row.tasks.map((task) => <tr key={task.id}><td><strong>{row.committeeName}</strong></td><td><span className="table-task-title">{task.title}</span>{task.description && <small>{task.description}</small>}</td><td><select className={`status-select ${statusMeta[task.status]?.className || "status-new"}`} value={task.status} disabled={updatingTaskId === task.id} onChange={(event) => onStatusChange?.(task.id, event.target.value as TaskItem["status"])}>{Object.entries(statusMeta).map(([value, meta]) => <option key={value} value={value}>{meta.label}</option>)}</select></td><td><select className="rating-select" aria-label={`تقييم ${task.title}`} value={task.rating ?? ""} disabled={updatingRatingId === task.id} onChange={(event) => event.target.value && onRatingChange?.(task.id, Number(event.target.value))}><option value="">بدون تقييم</option>{Array.from({ length: 10 }, (_, index) => <option key={index + 1} value={index + 1}>{index + 1} / 10</option>)}</select></td><td><span className="task-date"><Clock3 size={13} /> {formatDate(task.createdAt)}</span></td><td>{task.attachmentUrl ? <a className="table-download" href={task.attachmentUrl} download={task.attachmentName || undefined}><Paperclip size={14} /> تحميل</a> : <span className="no-attachment">بدون مرفق</span>}</td><td><button className="delete-button table-delete-button" type="button" disabled={deletingTaskId === task.id} onClick={() => onDeleteTask?.(task)}><Trash2 size={14} /> {deletingTaskId === task.id ? "جارٍ الحذف..." : "حذف"}</button></td></tr>))}</tbody></table></div> : <div className="task-list">{filteredTasks.map((task) => <article className="task-card" key={task.id}><div className="task-card-top">{statusBadge(task)}<span className="task-date"><Clock3 size={13} /> {formatDate(task.createdAt)}</span></div><div className="task-card-main"><span className="task-number">#{String(task.id).padStart(3, "0")}</span><div><h3>{task.title}</h3>{task.description && <p>{task.description}</p>}{task.rating !== null && <span className="task-rating"><Sparkles size={13} /> التقييم: <strong>{task.rating} / 10</strong></span>}</div></div>{task.attachmentUrl && <a className="task-attachment" href={task.attachmentUrl} download={task.attachmentName || undefined}><Paperclip size={14} /> {task.attachmentName || "تحميل مرفق التسك"}</a>}</article>)}</div>}
  </section>;
}

function NotificationInbox({ notifications }: { notifications: NotificationItem[] }) {
  if (!notifications.length) return null;
  return <section className="notification-inbox"><div className="notification-inbox-heading"><span className="notification-bell"><Bell size={16} /></span><div><strong>تحديثات مساحتك</strong><small>{notifications.length} إشعار جديد</small></div></div><div className="notification-items">{notifications.slice(0, 3).map((notification) => <div className="notification-item" key={notification.id}><span className="notification-dot" /><div><strong>{notification.message}</strong><small>{formatDate(notification.createdAt)}</small></div></div>)}</div></section>;
}

function ExecutiveOverview({ tasks, media, notifications }: { tasks: TaskItem[]; media: MediaItem[]; notifications: NotificationItem[] }) {
  const committeeOrder = ["hr", "logistics", "pr", "social", "projects", "training"];
  const committeeLabels: Record<string, string> = { hr: "الاتش ار", logistics: "التنظيم", pr: "العلاقات العامة", social: "السوشيال ميديا", projects: "المشروعات والمبادرات", training: "التدريب والتطوير" };
  const approved = tasks.filter((task) => task.status === "approved").length;
  const progress = tasks.length ? Math.round((approved / tasks.length) * 100) : 0;
  return <section className="executive-overview">
    <div className="overview-heading"><div><span className="eyebrow"><BarChart3 size={14} /> مركز القيادة</span><h2>نظرة سريعة على أداء اللجان</h2></div><span className="overview-live"><i /> بيانات محدثة تلقائيًا</span></div>
    <div className="overview-stats"><div className="overview-stat"><span className="overview-stat-icon navy"><ClipboardList size={19} /></span><div><strong>{tasks.length}</strong><small>إجمالي التسكات</small></div></div><div className="overview-stat"><span className="overview-stat-icon gold"><CheckCircle2 size={19} /></span><div><strong>{approved}</strong><small>تسكات معتمدة</small></div></div><div className="overview-stat"><span className="overview-stat-icon blue"><FolderOpen size={19} /></span><div><strong>{media.length}</strong><small>ملفات وفيديوهات</small></div></div><div className="overview-stat"><span className="overview-stat-icon rose"><Bell size={19} /></span><div><strong>{notifications.length}</strong><small>إشعارات جديدة</small></div></div></div>
    <div className="overview-grid"><div className="progress-card"><div className="overview-card-title"><h3>تقدم اللجان</h3><strong>{progress}%</strong></div>{committeeOrder.map((id) => { const committeeTasks = tasks.filter((task) => task.committeeId === id); const done = committeeTasks.filter((task) => task.status === "approved").length; const percent = committeeTasks.length ? Math.round((done / committeeTasks.length) * 100) : 0; return <div className="committee-progress" key={id}><div><span>{committeeLabels[id]}</span><small>{done}/{committeeTasks.length} معتمد</small></div><div className="progress-track"><i style={{ width: `${percent}%` }} /></div></div>; })}</div><div className="activity-card"><div className="overview-card-title"><h3>آخر النشاطات</h3><span><Bell size={15} /> {notifications.length}</span></div>{tasks.slice(0, 4).map((task) => <div className="activity-row" key={task.id}><span className="activity-dot" /><div><strong>{task.title}</strong><small>{task.committeeName || task.committeeId} · {formatDate(task.createdAt)}</small></div></div>)}{tasks.length === 0 && <p className="overview-empty">لا توجد نشاطات حتى الآن.</p>}</div></div>
  </section>;
}

function Workspace({ session, committees, onLogout }: { session: Session; committees: Committee[]; onLogout: () => void }) {
  const [tab, setTab] = useState<"videos" | "pdf">("videos");
  const [updatingTaskId, setUpdatingTaskId] = useState<number | null>(null);
  const [updatingRatingId, setUpdatingRatingId] = useState<number | null>(null);
  const [deletingTaskId, setDeletingTaskId] = useState<number | null>(null);
  const [deletingMediaId, setDeletingMediaId] = useState<number | null>(null);
  const mediaInput = useMemo(() => ({ token: session.token, committeeId: session.committeeId }), [session.token, session.committeeId]);
  const scheduleInput = useMemo(() => ({ token: session.token, committeeId: session.isExecutive ? "all" : session.committeeId }), [session.token, session.committeeId, session.isExecutive]);
  const mediaQuery = trpc.media.list.useQuery(mediaInput, { enabled: Boolean(session.token), refetchInterval: 15000 });
  const scheduleQuery = trpc.schedule.list.useQuery(scheduleInput, { enabled: Boolean(session.token), refetchInterval: 15000 });
  const tasksQuery = trpc.tasks.list.useQuery({ token: session.token }, { enabled: Boolean(session.token), refetchInterval: 10000 });
  const notificationsQuery = trpc.notifications.list.useQuery({ token: session.token }, { enabled: Boolean(session.token), refetchInterval: 10000 });
  const updateStatus = trpc.tasks.updateStatus.useMutation({ onSuccess: () => { setUpdatingTaskId(null); tasksQuery.refetch(); notificationsQuery.refetch(); toast.success("تم تحديث حالة التسك"); }, onError: (error) => { setUpdatingTaskId(null); toast.error(error.message); } });
  const updateRating = trpc.tasks.updateRating.useMutation({ onSuccess: () => { setUpdatingRatingId(null); tasksQuery.refetch(); toast.success("تم حفظ تقييم التسك"); }, onError: (error) => { setUpdatingRatingId(null); toast.error(error.message); } });
  const deleteTask = trpc.tasks.remove.useMutation({ onSuccess: () => { setDeletingTaskId(null); tasksQuery.refetch(); notificationsQuery.refetch(); toast.success("تم حذف التسك نهائيًا"); }, onError: (error) => { setDeletingTaskId(null); toast.error(error.message); } });
  const deleteMedia = trpc.media.remove.useMutation({ onSuccess: () => { setDeletingMediaId(null); mediaQuery.refetch(); toast.success("تم حذف الملف من جميع مساحات اللجان"); }, onError: (error) => { setDeletingMediaId(null); toast.error(error.message); } });
  const media = (mediaQuery.data ?? []) as MediaItem[];
  const tasks = (tasksQuery.data ?? []) as TaskItem[];
  const notifications = (notificationsQuery.data ?? []) as NotificationItem[];
  const schedules = (scheduleQuery.data ?? []) as ScheduleItem[];
  const videos = media.filter((item) => item.type === "video");
  const pdfs = media.filter((item) => item.type === "pdf");
  return <div className="workspace-page">
    <Header onCommittees={() => undefined} onAbout={() => undefined} />
    <main className="shell workspace-main">
      <div className="workspace-topline"><button className="back-link" onClick={onLogout}><ArrowLeft size={15} /> العودة للجان</button><span className="workspace-badge"><span /> مساحة {session.isExecutive ? "إدارية" : "خاصة"}</span></div>
      <div className="workspace-title-row"><div><span className="eyebrow">لوحة اللجنة</span><h1>{session.committeeName}</h1><p>محتوى آمن ومخصص لأعضاء اللجنة — آخر تحديث تلقائيًا.</p></div><button className="logout-button" onClick={onLogout}><LogOut size={16} /> تسجيل الخروج</button></div>
      <div className="workspace-stats"><div><span className="stat-icon blue"><FolderOpen size={18} /></span><span><strong>{media.length}</strong><small>إجمالي الملفات</small></span></div><div><span className="stat-icon purple"><Film size={18} /></span><span><strong>{videos.length}</strong><small>فيديوهات متاحة</small></span></div><div><span className="stat-icon amber"><FileText size={18} /></span><span><strong>{pdfs.length}</strong><small>ملفات PDF</small></span></div><div className="live-stat"><i /> مزامنة مباشرة</div></div>
      <SchedulePanel session={session} committees={committees} schedules={schedules} onChanged={() => scheduleQuery.refetch()} />
      {!session.isExecutive && <NotificationInbox notifications={notifications} />}
      {session.isExecutive && <ExecutiveOverview tasks={tasks} media={media} notifications={notifications} />}
      {session.isExecutive && <UploadPanel session={session} committees={committees} onUploaded={() => mediaQuery.refetch()} />}
      {!session.isExecutive && <TaskSubmitPanel session={session} onSubmitted={() => tasksQuery.refetch()} />}
      <TaskBoard tasks={tasks} isExecutive={session.isExecutive} updatingTaskId={updatingTaskId} updatingRatingId={updatingRatingId} deletingTaskId={deletingTaskId} onStatusChange={(taskId, status) => { setUpdatingTaskId(taskId); updateStatus.mutate({ token: session.token, taskId, status }); }} onRatingChange={(taskId, rating) => { setUpdatingRatingId(taskId); updateRating.mutate({ token: session.token, taskId, rating }); }} onDeleteTask={(task) => { if (window.confirm(`هل أنت متأكد من حذف التسك «${task.title}»؟ لا يمكن التراجع عن هذا الإجراء.`)) { setDeletingTaskId(task.id); deleteTask.mutate({ token: session.token, taskId: task.id }); } }} />
      <section className="library-section">
        <div className="library-heading"><div><span className="eyebrow">المكتبة الرقمية</span><h2>محتوى اللجنة</h2></div><span className="updated-label">تحديث تلقائي كل 15 ثانية</span></div>
        <div className="media-tabs"><button className={tab === "videos" ? "active" : ""} onClick={() => setTab("videos")}><Film size={17} /> الفيديوهات <b>{videos.length}</b></button><button className={tab === "pdf" ? "active" : ""} onClick={() => setTab("pdf")}><FileText size={17} /> الملفات والـ PDF <b>{pdfs.length}</b></button></div>
        {mediaQuery.isLoading ? <div className="loading-state"><div className="loader" /> جارٍ تحميل محتوى اللجنة...</div> : <div className="media-grid">{(tab === "videos" ? videos : pdfs).length === 0 ? <EmptyState type={tab === "videos" ? "video" : "pdf"} /> : (tab === "videos" ? videos : pdfs).map((item) => <MediaCard item={item} key={item.id} canDelete={session.isExecutive} deleting={deletingMediaId === item.id} onDelete={(mediaItem) => { if (window.confirm(`هل أنت متأكد من حذف «${mediaItem.title}»؟ سيختفي من جميع اللجان الموزع عليها.`)) { setDeletingMediaId(mediaItem.id); deleteMedia.mutate({ token: session.token, mediaId: mediaItem.id }); } }} />)}</div>}
      </section>
    </main>
  </div>;
}

export default function Home() {
  const committeesQuery = trpc.committee.list.useQuery();
  const committeeStatsQuery = trpc.committee.stats.useQuery();
  const [loginError, setLoginError] = useState("");
  const login = trpc.committee.login.useMutation({ onSuccess: (result) => { setLoginError(""); setSession(result); setSelectedCommittee(null); toast.success(`مرحبًا بك في ${result.committeeName}`); }, onError: (error) => { setLoginError(error.message); toast.error(error.message); } });
  const committees = (committeesQuery.data ?? []) as Committee[];
  const committeeStats = (committeeStatsQuery.data ?? []) as CommitteeStat[];
  const [selectedCommittee, setSelectedCommittee] = useState<Committee | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [showIntro, setShowIntro] = useState(true);
  useEffect(() => {
    if (window.sessionStorage.getItem("level-up-plane-intro-seen") === "1") setShowIntro(false);
  }, []);
  const completeIntro = useCallback(() => {
    window.sessionStorage.setItem("level-up-plane-intro-seen", "1");
    setShowIntro(false);
  }, []);
  const selectCommittee = (committee: Committee) => { setLoginError(""); setSelectedCommittee(committee); };
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  if (session) return <Workspace session={session} committees={committees} onLogout={() => setSession(null)} />;
  return <div className="app-shell" id="top">
    <Header onCommittees={() => scrollTo("committees")} onAbout={() => scrollTo("about")} />
    <main>
      <section className="hero shell"><div className="hero-copy"><div className="hero-kicker"><span className="kicker-dot" /> البرنامج التأهيلي الرسمي لأعضاء YDP</div><h1><span className="level-up-title">LEVEL UP</span><br /><em>نتعلم، ننجز، ونرتقي.</em></h1><p>مساحة رقمية موحّدة لأعضاء YDP تُمكّن اللجان من مشاركة المعرفة، تسليم التسك، وتحويل الأفكار إلى مبادرات ملموسة.</p><div className="hero-actions"><button className="primary-button" onClick={() => scrollTo("committees")}>دخول مساحة لجنتك <ArrowLeft size={17} /></button><button className="text-button" onClick={() => scrollTo("about")}>استكشف المنصة <ArrowUpRight size={17} /></button></div><div className="hero-trust"><ShieldCheck size={17} /><span>وصول محمي بكلمة مرور</span><span className="trust-separator" /><span>تسليم التسك ومحتوى مخصص</span></div></div><div className="hero-visual"><div className="visual-orbit orbit-one" /><div className="visual-orbit orbit-two" /><div className="visual-panel"><span className="visual-label">من الفكرة إلى الأثر</span><div className="visual-numbers"><strong>07</strong><span>لجان تعمل<br />بتناغم</span></div><div className="visual-bars"><i /><i /><i /><i /></div><div className="visual-footer"><span><CircleCheck size={14} /> منظومة موحدة</span><ArrowUpRight size={18} /></div></div><span className="floating-note note-top"><Sparkles size={14} /> طاقات شابة</span><span className="floating-note note-bottom"><Radio size={14} /> أثر مستمر</span></div></section>
      <section className="principles shell" id="about"><div className="section-intro"><span className="eyebrow">لماذا هذه المنصة؟</span><h2>كل لجنة، مساحة<br /><span>كل مساحة، أثر.</span></h2></div><div className="principle-grid"><div><span className="principle-icon"><LockKeyhole size={20} /></span><h3>وصول آمن</h3><p>نحافظ على خصوصية كل لجنة عبر وصول محمي ومحتوى موزّع بدقة.</p></div><div><span className="principle-icon"><LayoutGrid size={20} /></span><h3>مساحة موحدة</h3><p>كل ما تحتاجه اللجنة من فيديوهات وملفات في مكان واحد ومنظم.</p></div><div><span className="principle-icon"><ArrowUpRight size={20} /></span><h3>أثر قابل للقياس</h3><p>حوّل العمل اليومي إلى معرفة مشتركة تدعم قرارات أفضل.</p></div></div></section>
      <section className="program-section shell" id="program"><div className="program-intro"><span className="eyebrow"><BookOpen size={14} /> عن Level Up</span><h2>برنامج تأهيلي يحوّل<br /><span>الطاقة إلى أثر.</span></h2><p>منظومة عملية لأعضاء YDP تجمع بين التعلم، التنفيذ، والمتابعة في مساحة واحدة واضحة.</p></div><div className="program-steps"><div className="program-step"><span>01</span><div><strong>نتعلم</strong><p>نبني المعرفة والمهارات الأساسية لكل عضو.</p></div></div><div className="program-step"><span>02</span><div><strong>ننجز</strong><p>نحوّل الأفكار إلى تسكات ومبادرات قابلة للتنفيذ.</p></div></div><div className="program-step"><span>03</span><div><strong>نرتقي</strong><p>نراجع النتائج ونشارك الخبرات ونصنع أثرًا مستمرًا.</p></div></div></div></section>
      <section className="committees-section shell" id="committees"><div className="section-heading"><div><span className="eyebrow">اختر مساحتك</span><h2>لجان تعمل كفريق واحد</h2></div><span className="section-counter">{committees.length || 7} لجان متخصصة</span></div>{committeesQuery.isLoading ? <div className="loading-state"><div className="loader" /> جارٍ تجهيز مساحات اللجان...</div> : <div className="committee-grid">{committees.map((committee) => <CommitteeCard key={committee.committeeId} committee={committee} stat={committeeStats.find((item) => item.committeeId === committee.committeeId)} onSelect={selectCommittee} />)}</div>}</section>
      <section className="closing-banner shell"><div><span className="eyebrow">جاهز للخطوة التالية؟</span><h2>ابدأ من مساحتك،<br />واترك بصمتك.</h2></div><button className="light-button" onClick={() => scrollTo("committees")}>اختيار اللجنة <ArrowLeft size={17} /></button></section>
    </main>
    <footer className="site-footer shell"><span>© 2026 LEVEL UP</span><span>البرنامج التأهيلي الرسمي لأعضاء YDP</span><span>تحت رعاية وزارة الشباب والرياضة</span></footer>
    {selectedCommittee && <LoginPanel committee={selectedCommittee} loading={login.isPending} error={loginError} onClearError={() => setLoginError("")} onClose={() => { setLoginError(""); setSelectedCommittee(null); }} onLogin={(password) => { setLoginError(""); login.mutate({ committeeId: selectedCommittee.committeeId, password }); }} />}
    {showIntro && <LaunchIntro onComplete={completeIntro} />}
  </div>;
}
